// Learn more https://docs.expo.io/guides/customizing-metro
const { getDefaultConfig } = require('expo/metro-config');

const defaultConfig = getDefaultConfig(__dirname);

// Make sure we correctly resolve all file types
defaultConfig.resolver.sourceExts = [
  'jsx', 'js', 'ts', 'tsx', 'json', 
  'cjs', 'mjs'
];

defaultConfig.resolver.resolverMainFields = [
  'react-native', 'browser', 'main'
];

// Ensure proper handling of assets
defaultConfig.resolver.assetExts = [
  ...defaultConfig.resolver.assetExts,
  'db', 'sqlite'
];

// Export the configuration
module.exports = defaultConfig;
