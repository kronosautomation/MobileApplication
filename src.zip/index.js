import 'react-native-gesture-handler';
import { AppRegistry } from 'react-native';
import { registerRootComponent } from 'expo';
import App from './App.minimal.tsx';  // Use the minimal app that we know works

// Register the app
AppRegistry.registerComponent('main', () => App);
registerRootComponent(App);

console.log('Application registration complete - using minimal app for debugging');
