import * as SQLite from 'expo-sqlite';
import { Platform } from 'react-native';

// Define proper types for SQLite interactions
type SQLTransaction = {
  executeSql: (
    sqlStatement: string,
    args?: any[],
    success?: (transaction: SQLTransaction, resultSet: SQLResultSet) => void,
    error?: (transaction: SQLTransaction, error: Error) => boolean
  ) => void;
};

type SQLResultSet = {
  rows: {
    length: number;
    item: (index: number) => any;
    _array?: any[];
  };
  rowsAffected: number;
  insertId?: number;
};

type SQLiteDatabase = {
  transaction: (
    txFunction: (tx: SQLTransaction) => void,
    error?: (error: Error) => void,
    success?: () => void
  ) => void;
  closeAsync?: () => Promise<void>;
  deleteAsync?: () => Promise<void>;
};

/**
 * Database service for SQLite operations
 * Optimized for compatibility with Hermes engine and newer expo-sqlite versions
 */
class DatabaseService {
  private db: SQLiteDatabase | null = null;
  private isInitialized = false;
  private readonly DB_NAME = 'mindfulmastery.db';

  constructor() {
    // Defer initialization to avoid issues at import time
  }

  /**
   * Initialize the database connection
   * Must be called before using any other methods
   * @returns Promise<boolean> indicating success
   */
  public async initialize(): Promise<boolean> {
    if (this.isInitialized) return true;
    
    try {
      // Check if running on web platform where SQLite is not supported
      if (Platform.OS === 'web') {
        throw new Error('SQLite is not supported on web platform.');
      }
      
      // Open the database using the available API
      // Note: We use the standard openDatabase method as it's the most widely supported
      this.db = SQLite.openDatabase(this.DB_NAME);
      
      // Initialize database schema
      await this.initDatabase();
      
      this.isInitialized = true;
      return true;
    } catch (error) {
      console.error('Failed to initialize database service:', error instanceof Error ? error.message : String(error));
      throw error; // Let the caller handle the error instead of using a mock
    }
  }

  /**
   * Initialize database tables
   */
  private async initDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    return new Promise<void>((resolve, reject) => {
      try {
        this.db!.transaction(
          function(tx: SQLTransaction) {
            // Meditations table - stores downloaded meditation data
            tx.executeSql(
              `CREATE TABLE IF NOT EXISTS meditations (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT,
                narrator TEXT,
                durationInSeconds INTEGER,
                difficultyLevel INTEGER,
                imageUrl TEXT,
                audioUrl TEXT,
                localAudioPath TEXT,
                isDownloaded INTEGER DEFAULT 0,
                minimumSubscriptionTier INTEGER DEFAULT 0,
                categories TEXT,
                tags TEXT,
                lastSyncedAt TEXT,
                createdAt TEXT,
                updatedAt TEXT
              )`
            );

            // Journal entries table - stores journal entries for offline access
            tx.executeSql(
              `CREATE TABLE IF NOT EXISTS journal_entries (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT,
                mood INTEGER,
                anxietyLevel INTEGER,
                isPrivate INTEGER DEFAULT 1,
                isSynced INTEGER DEFAULT 0,
                localCreatedAt TEXT,
                localUpdatedAt TEXT,
                serverCreatedAt TEXT,
                serverUpdatedAt TEXT
              )`
            );

            // Sync queue table - stores operations to perform when back online
            tx.executeSql(
              `CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entityType TEXT NOT NULL,
                entityId TEXT NOT NULL,
                operation TEXT NOT NULL,
                data TEXT,
                createdAt TEXT NOT NULL,
                attempts INTEGER DEFAULT 0
              )`
            );
            
            // Subscription status table - stores current subscription information
            tx.executeSql(
              `CREATE TABLE IF NOT EXISTS subscription_status (
                isValid INTEGER DEFAULT 0,
                expiryDate TEXT,
                tier INTEGER DEFAULT 0,
                lastVerifiedOnline TEXT NOT NULL
              )`
            );
          },
          function(error: Error) {
            console.error('Error creating database schema:', error.message);
            reject(error);
          },
          function() {
            console.log('Database schema initialized successfully');
            resolve();
          }
        );
      } catch (error) {
        console.error('Transaction error in initDatabase:', error instanceof Error ? error.message : String(error));
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  /**
   * Execute a SQL query with parameters
   * @param query SQL query string
   * @param params Parameters for the query
   * @returns Promise resolving to the result rows
   */
  async executeQuery<T = any>(query: string, params: any[] = []): Promise<T[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    return new Promise<T[]>((resolve, reject) => {
      try {
        this.db!.transaction(
          function(tx: SQLTransaction) {
            tx.executeSql(
              query,
              params,
              function(_: SQLTransaction, result: SQLResultSet) {
                const rows: T[] = [];
                // Use _array if available for better performance
                if (result.rows._array) {
                  resolve(result.rows._array as T[]);
                } else {
                  for (let i = 0; i < result.rows.length; i++) {
                    rows.push(result.rows.item(i) as T);
                  }
                  resolve(rows);
                }
              },
              function(_: SQLTransaction, error: Error): boolean {
                console.error('SQL error:', error.message);
                reject(error);
                return false;
              }
            );
          },
          function(transactionError: Error) {
            console.error('Transaction error:', transactionError.message);
            reject(transactionError);
          }
        );
      } catch (error) {
        console.error('executeQuery error:', error instanceof Error ? error.message : String(error));
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  /**
   * Execute an insert query and return the inserted ID
   * @param query SQL query string
   * @param params Parameters for the query
   * @returns Promise resolving to the inserted ID (or row count)
   */
  async executeInsert(query: string, params: any[] = []): Promise<number> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    return new Promise<number>((resolve, reject) => {
      try {
        this.db!.transaction(
          function(tx: SQLTransaction) {
            tx.executeSql(
              query,
              params,
              function(_: SQLTransaction, result: SQLResultSet) {
                resolve(result.insertId ?? result.rowsAffected);
              },
              function(_: SQLTransaction, error: Error): boolean {
                console.error('SQL error in insert:', error.message);
                reject(error);
                return false;
              }
            );
          },
          function(transactionError: Error) {
            console.error('Transaction error in insert:', transactionError.message);
            reject(transactionError);
          }
        );
      } catch (error) {
        console.error('executeInsert error:', error instanceof Error ? error.message : String(error));
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  /**
   * Execute an update or delete query and return the number of affected rows
   * @param query SQL query string
   * @param params Parameters for the query
   * @returns Promise resolving to the number of affected rows
   */
  async executeUpdate(query: string, params: any[] = []): Promise<number> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    return new Promise<number>((resolve, reject) => {
      try {
        this.db!.transaction(
          function(tx: SQLTransaction) {
            tx.executeSql(
              query,
              params,
              function(_: SQLTransaction, result: SQLResultSet) {
                resolve(result.rowsAffected);
              },
              function(_: SQLTransaction, error: Error): boolean {
                console.error('SQL error in update:', error.message);
                reject(error);
                return false;
              }
            );
          },
          function(transactionError: Error) {
            console.error('Transaction error in update:', transactionError.message);
            reject(transactionError);
          }
        );
      } catch (error) {
        console.error('executeUpdate error:', error instanceof Error ? error.message : String(error));
        reject(error instanceof Error ? error : new Error(String(error)));
      }
    });
  }

  /**
   * Close the database connection
   */
  async closeDatabase(): Promise<void> {
    try {
      if (this.db && this.db.closeAsync) {
        await this.db.closeAsync();
        this.db = null;
        this.isInitialized = false;
      }
    } catch (error) {
      console.error('Error closing database:', error instanceof Error ? error.message : String(error));
      throw error;
    }
  }
}

// Singleton instance
export default new DatabaseService();