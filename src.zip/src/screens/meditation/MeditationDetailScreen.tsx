import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity, 
  ScrollView, 
  ActivityIndicator,
  Alert,
  Platform
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { MeditationStackParamList, GuidedMeditation, DifficultyLevel } from '../../types';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context';
import { useMeditationDetails } from '../../hooks';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ErrorDisplay, useAppError } from '../../components/common';
import meditationService from '../../services/meditationService';

type MeditationDetailRouteProp = RouteProp<MeditationStackParamList, 'MeditationDetail'>;
type MeditationDetailNavigationProp = NativeStackNavigationProp<MeditationStackParamList, 'MeditationDetail'>;

const MeditationDetailScreen: React.FC = () => {
  const route = useRoute<MeditationDetailRouteProp>();
  const navigation = useNavigation<MeditationDetailNavigationProp>();
  const { currentTheme, isDark } = useTheme();
  const { colors } = currentTheme;
  const { user } = useAuth();
  const { showError } = useAppError();
  
  const { meditationId } = route.params;
  
  // Use the custom hook for meditation details
  const {
    meditation,
    isLoading,
    error,
    formatDuration,
    getDifficultyLabel
  } = useMeditationDetails(meditationId);
  
  // Download state
  const [isDownloaded, setIsDownloaded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  
  // Check if meditation is downloaded
  useEffect(() => {
    const checkDownloadStatus = async () => {
      if (meditation) {
        const downloaded = await meditationService.isMeditationDownloaded(meditation.id);
        setIsDownloaded(downloaded);
      }
    };
    
    checkDownloadStatus();
  }, [meditation]);
  
  const handleStartMeditation = () => {
    if (meditation) {
      navigation.navigate('MeditationPlayer', { meditation });
    }
  };
  
  // Handle download/remove download of meditation
  const handleDownload = async () => {
    if (!meditation) return;
    
    if (isDownloaded) {
      // Confirm removal of download
      Alert.alert(
        'Remove Download',
        'Are you sure you want to remove this meditation from your downloads?',
        [
          {
            text: 'Cancel',
            style: 'cancel'
          },
          {
            text: 'Remove',
            style: 'destructive',
            onPress: async () => {
              try {
                await meditationService.removeMeditationDownload(meditation);
                setIsDownloaded(false);
                showError('Download removed', 'info');
              } catch (error) {
                console.error('Error removing download:', error);
                showError('Failed to remove download', 'error');
              }
            }
          }
        ]
      );
    } else {
      // Start download
      setIsDownloading(true);
      setDownloadProgress(0);
      
      try {
        const success = await meditationService.downloadMeditationAudio(meditation, (progress) => {
          setDownloadProgress(progress);
        });
        
        if (success) {
          setIsDownloaded(true);
          showError('Download complete', 'success');
        } else {
          showError('Download failed', 'error');
        }
      } catch (error) {
        console.error('Error downloading meditation:', error);
        showError('Download failed', 'error');
      } finally {
        setIsDownloading(false);
      }
    }
  };
  
  if (isLoading) {
    return (
      <SafeAreaView style={[styles.loadingContainer, { backgroundColor: colors.background.default }]}>
        <ActivityIndicator 
          size="large" 
          color={colors.primary.main} 
        />
        <Text 
          style={[styles.loadingText, { color: colors.text.secondary }]}
          accessible={true}
          accessibilityLabel="Loading meditation details"
          accessibilityState={{ busy: true }}
        >
          Loading meditation...
        </Text>
      </SafeAreaView>
    );
  }
  
  if (error || !meditation) {
    return (
      <SafeAreaView style={[styles.errorContainer, { backgroundColor: colors.background.default }]}>
        <ErrorDisplay 
          error={error || 'Meditation not found'} 
          onRetry={() => meditation ? null : navigation.goBack()}
        />
      </SafeAreaView>
    );
  }
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background.default }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => navigation.goBack()}
          accessible={true}
          accessibilityRole="button"
          accessibilityLabel="Back to meditation list"
          accessibilityHint="Returns to the previous screen"
        >
          <Ionicons name="chevron-back" size={28} color={colors.text.primary} />
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.scrollView}>
        {/* Meditation Image */}
        <View style={styles.imageContainer}>
          <Image 
            source={{ uri: meditation.imageUrl || 'https://via.placeholder.com/400x200' }} 
            style={styles.image}
            resizeMode="cover"
            accessible={true}
            accessibilityLabel={`Image for ${meditation.title} meditation`}
            accessibilityRole="image"
          />
        </View>
        
        {/* Title and details */}
        <View style={styles.contentContainer}>
          <Text 
            style={[styles.title, { color: colors.text.primary }]}
            accessible={true}
            accessibilityRole="header"
          >
            {meditation.title}
          </Text>
          
          <View style={styles.detailsRow}>
            <View style={styles.detailItem}>
              <Ionicons name="time-outline" size={18} color={colors.text.secondary} />
              <Text style={[styles.detailText, { color: colors.text.secondary }]}>
                {formatDuration(meditation.durationInSeconds)}
              </Text>
            </View>
            
            <View style={styles.detailItem}>
              <Ionicons name="fitness-outline" size={18} color={colors.text.secondary} />
              <Text style={[styles.detailText, { color: colors.text.secondary }]}>
                {getDifficultyLabel(meditation.difficultyLevel)}
              </Text>
            </View>
            
            <View style={styles.detailItem}>
              <Ionicons name="person-outline" size={18} color={colors.text.secondary} />
              <Text style={[styles.detailText, { color: colors.text.secondary }]}>
                {meditation.narrator}
              </Text>
            </View>
          </View>
          
          {/* Description */}
          <Text style={[styles.sectionTitle, { color: colors.text.primary }]}>
            Description
          </Text>
          <Text 
            style={[styles.description, { color: colors.text.secondary }]}
            accessible={true}
            accessibilityLabel={`Description: ${meditation.description}`}
            accessibilityRole="text"
          >
            {meditation.description}
          </Text>
          
          {/* Categories */}
          {meditation.categories && meditation.categories.length > 0 && (
            <>
              <Text style={[styles.sectionTitle, { color: colors.text.primary }]}>
                Categories
              </Text>
              <View style={styles.tagsContainer}>
                {meditation.categories.map((category, index) => (
                  <View 
                    key={`category-${index}`}
                    style={[styles.tag, { backgroundColor: isDark ? colors.neutral.dark : colors.neutral.light }]}
                    accessible={true}
                    accessibilityLabel={`Category: ${category}`}
                    accessibilityRole="text"
                  >
                    <Text style={[styles.tagText, { color: colors.text.secondary }]}>
                      {category}
                    </Text>
                  </View>
                ))}
              </View>
            </>
          )}
          
          {/* Tags */}
          {meditation.tags && meditation.tags.length > 0 && (
            <>
              <Text style={[styles.sectionTitle, { color: colors.text.primary }]}>
                Tags
              </Text>
              <View style={styles.tagsContainer}>
                {meditation.tags.map((tag, index) => (
                  <View 
                    key={`tag-${index}`}
                    style={[styles.tag, { backgroundColor: isDark ? colors.neutral.dark : colors.neutral.light }]}
                    accessible={true}
                    accessibilityLabel={`Tag: ${tag}`}
                    accessibilityRole="text"
                  >
                    <Text style={[styles.tagText, { color: colors.text.secondary }]}>
                      {tag}
                    </Text>
                  </View>
                ))}
              </View>
            </>
          )}
        </View>
      </ScrollView>
      
      {/* Action buttons */}
      <View style={[styles.buttonContainer, { backgroundColor: colors.background.default }]}>
        <View style={styles.buttonRow}>
          {/* Start button */}
          <TouchableOpacity 
            style={[
              styles.startButton, 
              { 
                backgroundColor: colors.primary.main,
                flex: Platform.OS !== 'web' ? 2 : 1
              }
            ]}
            onPress={handleStartMeditation}
            accessible={true}
            accessibilityRole="button"
            accessibilityLabel="Start meditation"
            accessibilityHint="Begins the guided meditation session"
          >
            <Ionicons name="play" size={24} color={colors.primary.contrast} />
            <Text style={[styles.startButtonText, { color: colors.primary.contrast }]}>
              Start Meditation
            </Text>
          </TouchableOpacity>
          
          {/* Download button - only show on native platforms */}
          {Platform.OS !== 'web' && (
            <TouchableOpacity 
              style={[
                styles.downloadButton, 
                { 
                  backgroundColor: isDark ? colors.background.paper : colors.neutral.light,
                  opacity: isDownloading ? 0.7 : 1
                }
              ]}
              onPress={handleDownload}
              disabled={isDownloading}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel={isDownloaded ? "Remove download" : isDownloading ? "Downloading" : "Download for offline use"}
              accessibilityState={{ disabled: isDownloading }}
            >
              {isDownloading ? (
                <>
                  <ActivityIndicator size="small" color={colors.primary.main} />
                  <Text style={[styles.downloadButtonText, { color: colors.text.secondary }]}>
                    {Math.round(downloadProgress * 100)}%
                  </Text>
                </>
              ) : (
                <>
                  <Ionicons 
                    name={isDownloaded ? "cloud-done" : "cloud-download-outline"} 
                    size={20} 
                    color={isDownloaded ? colors.success.main : colors.text.secondary} 
                  />
                  <Text style={[styles.downloadButtonText, { color: colors.text.secondary }]}>
                    {isDownloaded ? "Downloaded" : "Download"}
                  </Text>
                </>
              )}
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    marginTop: 16,
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 24,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  retryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  header: {
    paddingHorizontal: 16,
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    height: 40,
    width: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  imageContainer: {
    width: '100%',
    height: 220,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  contentContainer: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 16,
  },
  detailsRow: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  detailText: {
    marginLeft: 6,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Medium',
    marginTop: 20,
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    lineHeight: 24,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 5,
  },
  tag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  buttonContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.1)',
  },
  buttonRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  startButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    flex: 2,
  },
  startButtonText: {
    marginLeft: 8,
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  downloadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginLeft: 8,
    flex: 1,
  },
  downloadButtonText: {
    marginLeft: 8,
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
});

export default MeditationDetailScreen;
