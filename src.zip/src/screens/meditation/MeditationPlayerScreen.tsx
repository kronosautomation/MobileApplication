import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Animated,
  Alert,
  Platform,
  BackHandler,
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { MeditationStackParamList, GuidedMeditation } from '../../types';
import { useTheme } from '../../context/ThemeContext';
import { api } from '../../api';
import { useAuth } from '../../context';
import { SafeAreaView } from 'react-native-safe-area-context';
import Slider from '@react-native-community/slider';
import meditationService from '../../services/meditationService';
import { useAppError } from '../../components/common';

type MeditationPlayerRouteProp = RouteProp<MeditationStackParamList, 'MeditationPlayer'>;
type MeditationPlayerNavigationProp = NativeStackNavigationProp<MeditationStackParamList, 'MeditationPlayer'>;

const MeditationPlayerScreen: React.FC = () => {
  const route = useRoute<MeditationPlayerRouteProp>();
  const navigation = useNavigation<MeditationPlayerNavigationProp>();
  const { currentTheme, isDark } = useTheme();
  const { colors } = currentTheme;
  const { user } = useAuth();
  const { showError } = useAppError();
  
  const { meditation } = route.params;
  
  // Player state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [anxietyBefore, setAnxietyBefore] = useState<number | null>(null);
  
  // Animation values
  const breatheAnim = useRef(new Animated.Value(0)).current;
  
  // Simulate meditation playing
  const playerInterval = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    // Validate subscription before starting
    const validateAccess = async () => {
      try {
        // Validate access to premium content
        if (meditation.minimumSubscriptionTier > 0) {
          const canPlay = await meditationService.playMeditation(meditation);
          
          if (!canPlay) {
            showError('Subscription required for this meditation', 'error');
            navigation.goBack();
            return;
          }
        }
        
        // If we have offline content, make sure it's valid
        if (meditation.isDownloaded) {
          const isDownloaded = await meditationService.isMeditationDownloaded(meditation.id);
          if (!isDownloaded) {
            showError('Content not available offline', 'error');
            navigation.goBack();
            return;
          }
        }
        
        // Start the meditation session on the backend
        startSession();
      } catch (error) {
        console.error('Error validating meditation access:', error);
        showError('Unable to start meditation', 'error');
        navigation.goBack();
      }
    };
    
    validateAccess();
    
    // Start breathing animation
    startBreathingAnimation();
    
    // Android back button handling
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      handleBackPress();
      return true;
    });
    
    return () => {
      if (playerInterval.current) {
        clearInterval(playerInterval.current);
      }
      backHandler.remove();
    };
  }, []);
  
  // Ask for anxiety level and start session
  const startSession = () => {
    Alert.prompt(
      'Rate Your Anxiety',
      'On a scale of 1-10, how would you rate your anxiety level right now?',
      [
        {
          text: 'Skip',
          onPress: () => startMeditationSession(),
          style: 'cancel',
        },
        {
          text: 'Submit',
          onPress: (value) => {
            const anxietyValue = parseInt(value || '0');
            if (anxietyValue >= 1 && anxietyValue <= 10) {
              setAnxietyBefore(anxietyValue);
            }
            startMeditationSession();
          },
        },
      ],
      'plain-text',
      '',
      'number-pad'
    );
  };
  
  // Start the actual session with the backend
  const startMeditationSession = async () => {
    try {
      const response = await api.startMeditationSession(
        meditation.id,
        anxietyBefore || undefined
      );
      setSessionId(response.id);
    } catch (error) {
      console.error('Error starting meditation session:', error);
    }
  };
  
  useEffect(() => {
    if (isPlaying) {
      playerInterval.current = setInterval(() => {
        setCurrentTime((prev) => {
          const newTime = prev + 1;
          if (newTime >= meditation.durationInSeconds) {
            // Meditation complete
            if (playerInterval.current) {
              clearInterval(playerInterval.current);
            }
            handleMeditationComplete();
            return meditation.durationInSeconds;
          }
          return newTime;
        });
      }, 1000);
    } else {
      if (playerInterval.current) {
        clearInterval(playerInterval.current);
      }
    }
    
    return () => {
      if (playerInterval.current) {
        clearInterval(playerInterval.current);
      }
    };
  }, [isPlaying]);
  
  const startBreathingAnimation = () => {
    Animated.loop(
      Animated.sequence([
        // Breathe in
        Animated.timing(breatheAnim, {
          toValue: 1,
          duration: 4000,
          useNativeDriver: true,
        }),
        // Hold
        Animated.timing(breatheAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        // Breathe out
        Animated.timing(breatheAnim, {
          toValue: 0,
          duration: 4000,
          useNativeDriver: true,
        }),
        // Rest
        Animated.timing(breatheAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleSeek = (value: number) => {
    setCurrentTime(value);
  };
  
  const handleBackPress = () => {
    Alert.alert(
      'Exit Meditation',
      'Are you sure you want to exit? Your progress will not be saved.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Exit',
          onPress: () => {
            if (playerInterval.current) {
              clearInterval(playerInterval.current);
            }
            navigation.goBack();
          },
        },
      ]
    );
  };
  
  const handleMeditationComplete = () => {
    setIsPlaying(false);
    
    if (sessionId) {
      navigation.replace('MeditationComplete', { sessionId });
    } else {
      navigation.goBack();
    }
  };
  
  // Animation styles
  const circleScale = breatheAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 1.3],
  });
  
  const circleOpacity = breatheAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.5, 0.8],
  });
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background.default }]}>
      {/* Top control bar */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.closeButton} onPress={handleBackPress}>
          <Ionicons name="close" size={28} color={colors.text.primary} />
        </TouchableOpacity>
        
        <Text style={[styles.timerText, { color: colors.text.primary }]}>
          {formatTime(currentTime)} / {formatTime(meditation.durationInSeconds)}
        </Text>
      </View>
      
      {/* Meditation title */}
      <Text style={[styles.title, { color: colors.text.primary }]}>
        {meditation.title}
      </Text>
      
      {/* Breathing visualization */}
      <View style={styles.breatheContainer}>
        <Animated.View
          style={[
            styles.breatheCircle,
            { 
              backgroundColor: colors.primary.light,
              transform: [{ scale: circleScale }],
              opacity: circleOpacity,
            },
          ]}
        />
        
        <Text style={[styles.breatheText, { color: colors.text.primary }]}>
          {breatheAnim._value < 0.5 ? 'Breathe in...' : 'Breathe out...'}
        </Text>
      </View>
      
      {/* Playback controls */}
      <View style={styles.controlsContainer}>
        <Slider
          style={styles.slider}
          minimumValue={0}
          maximumValue={meditation.durationInSeconds}
          value={currentTime}
          onValueChange={handleSeek}
          minimumTrackTintColor={colors.primary.main}
          maximumTrackTintColor={colors.neutral.light}
          thumbTintColor={colors.primary.main}
        />
        
        <View style={styles.timeLabels}>
          <Text style={[styles.timeLabel, { color: colors.text.secondary }]}>
            {formatTime(currentTime)}
          </Text>
          <Text style={[styles.timeLabel, { color: colors.text.secondary }]}>
            {formatTime(meditation.durationInSeconds)}
          </Text>
        </View>
        
        <View style={styles.playbackButtons}>
          <TouchableOpacity style={styles.playbackButton} onPress={() => setCurrentTime(Math.max(0, currentTime - 15))}>
            <Ionicons name="play-back" size={24} color={colors.text.primary} />
            <Text style={[styles.skipText, { color: colors.text.secondary }]}>15s</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.playButton} onPress={handlePlayPause}>
            <Ionicons 
              name={isPlaying ? 'pause' : 'play'} 
              size={36} 
              color={colors.primary.contrastText}
              style={styles.playIcon}
            />
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.playbackButton} onPress={() => setCurrentTime(Math.min(meditation.durationInSeconds, currentTime + 15))}>
            <Ionicons name="play-forward" size={24} color={colors.text.primary} />
            <Text style={[styles.skipText, { color: colors.text.secondary }]}>15s</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  closeButton: {
    padding: 4,
  },
  timerText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
    paddingHorizontal: 32,
  },
  breatheContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  breatheCircle: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  breatheText: {
    position: 'absolute',
    fontSize: 20,
    fontFamily: 'Inter-Regular',
  },
  controlsContainer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  timeLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -8,
    marginBottom: 16,
  },
  timeLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  playbackButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playbackButton: {
    alignItems: 'center',
    marginHorizontal: 24,
  },
  skipText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    marginTop: 4,
  },
  playButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#4A90E2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  playIcon: {
    marginLeft: 4, // Fixed margin for all states
  },
});

export default MeditationPlayerScreen;