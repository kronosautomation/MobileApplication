import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useTheme } from '../../context/ThemeContext';
import { Text, Button } from '../../components/ui';
import { JournalEntryForm } from '../../components/journal/JournalEntryForm';
import { JournalStackParamList, PerformanceJournal } from '../../types';
import { journalService } from '../../api';
import { Ionicons } from '@expo/vector-icons';

type JournalEntryScreenNavigationProp = NativeStackNavigationProp<JournalStackParamList, 'JournalEntry'>;
type JournalEntryScreenRouteProp = RouteProp<JournalStackParamList, 'JournalEntry'>;

const JournalEntryScreen: React.FC = () => {
  const navigation = useNavigation<JournalEntryScreenNavigationProp>();
  const route = useRoute<JournalEntryScreenRouteProp>();
  const { currentTheme } = useTheme();
  const { colors } = currentTheme;
  
  const journalId = route.params?.journalId;
  const [isLoading, setIsLoading] = useState(false);
  const [journal, setJournal] = useState<Partial<PerformanceJournal> | null>(null);
  const [isEditing, setIsEditing] = useState(!!journalId);

  // If we have a journal ID, fetch the journal entry data
  React.useEffect(() => {
    const fetchJournal = async () => {
      if (journalId) {
        try {
          setIsLoading(true);
          const journalData = await journalService.getJournalById(journalId);
          setJournal(journalData);
        } catch (error) {
          console.error('Error fetching journal entry:', error);
          Alert.alert('Error', 'Failed to load journal entry');
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchJournal();
  }, [journalId]);

  // Handle form submission
  const handleSubmit = async (journalEntry: Partial<PerformanceJournal>) => {
    try {
      setIsLoading(true);
      
      if (isEditing && journalId) {
        // Update existing journal entry
        await journalService.updateJournal(journalId, journalEntry);
        navigation.navigate('JournalDetail', { journalId });
      } else {
        // Create new journal entry
        const newJournal = await journalService.createJournal(journalEntry);
        navigation.navigate('JournalDetail', { journalId: newJournal.id });
      }
    } catch (error) {
      console.error('Error saving journal entry:', error);
      Alert.alert(
        'Error',
        error instanceof Error ? error.message : 'Failed to save journal entry'
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Handle cancel button press
  const handleCancel = () => {
    navigation.goBack();
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background.default }]}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Ionicons 
            name="chevron-back" 
            size={24} 
            color={colors.text.primary} 
            onPress={handleCancel}
          />
          <Text variant="h3" style={styles.title}>
            {isEditing ? 'Edit Journal Entry' : 'New Journal Entry'}
          </Text>
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {isLoading && !journal && isEditing ? (
            <View style={styles.loadingContainer}>
              <Text>Loading journal entry...</Text>
            </View>
          ) : (
            <JournalEntryForm
              initialValues={journal || undefined}
              onSubmit={handleSubmit}
              onCancel={handleCancel}
              isLoading={isLoading}
            />
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  title: {
    marginLeft: 12,
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default JournalEntryScreen;
