import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../../context/ThemeContext';
import { Text } from '../../components/ui';
import { Ionicons } from '@expo/vector-icons';
import { DownloadManager } from '../../components/common';

const SettingsScreen: React.FC = () => {
  const navigation = useNavigation();
  const { currentTheme, themeMode, setThemeMode, isDark } = useTheme();
  const { colors } = currentTheme;

  // Settings state
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [reminderTime, setReminderTime] = useState('08:00 AM');
  const [downloadOverWifi, setDownloadOverWifi] = useState(true);
  const [downloadQuality, setDownloadQuality] = useState('High');
  const [autoPlayNext, setAutoPlayNext] = useState(false);
  const [keepScreenOn, setKeepScreenOn] = useState(true);
  const [backgroundSounds, setBackgroundSounds] = useState(true);
  const [downloadManagerVisible, setDownloadManagerVisible] = useState(false);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background.default }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.text.primary} />
        </TouchableOpacity>
        <Text variant="h3">Settings</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Theme settings */}
        <View style={[styles.section, { backgroundColor: colors.background.paper }]}>
          <Text variant="h4" style={styles.sectionTitle}>
            Display
          </Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Theme</Text>
              <Text variant="body2" color="secondary">
                {themeMode === 'light' 
                  ? 'Light' 
                  : themeMode === 'dark' 
                    ? 'Dark' 
                    : 'System'}
              </Text>
            </View>
            <View style={styles.themeButtons}>
              <TouchableOpacity 
                style={[
                  styles.themeButton, 
                  { 
                    backgroundColor: themeMode === 'light' 
                      ? colors.primary.main 
                      : colors.background.default,
                    borderColor: colors.neutral.lighter
                  }
                ]}
                onPress={() => setThemeMode('light')}
              >
                <Ionicons 
                  name="sunny-outline" 
                  size={18} 
                  color={themeMode === 'light' ? colors.primary.contrast : colors.text.primary} 
                />
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.themeButton, 
                  { 
                    backgroundColor: themeMode === 'dark' 
                      ? colors.primary.main 
                      : colors.background.default,
                    borderColor: colors.neutral.lighter
                  }
                ]}
                onPress={() => setThemeMode('dark')}
              >
                <Ionicons 
                  name="moon-outline" 
                  size={18} 
                  color={themeMode === 'dark' ? colors.primary.contrast : colors.text.primary} 
                />
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.themeButton, 
                  { 
                    backgroundColor: themeMode === 'system' 
                      ? colors.primary.main 
                      : colors.background.default,
                    borderColor: colors.neutral.lighter
                  }
                ]}
                onPress={() => setThemeMode('system')}
              >
                <Ionicons 
                  name="phone-portrait-outline" 
                  size={18} 
                  color={themeMode === 'system' ? colors.primary.contrast : colors.text.primary} 
                />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Keep Screen On During Meditation</Text>
            </View>
            <Switch
              value={keepScreenOn}
              onValueChange={setKeepScreenOn}
              trackColor={{ false: colors.neutral.light, true: colors.primary.light }}
              thumbColor={keepScreenOn ? colors.primary.main : colors.neutral.lighter}
            />
          </View>
        </View>

        {/* Notification settings */}
        <View style={[styles.section, { backgroundColor: colors.background.paper }]}>
          <Text variant="h4" style={styles.sectionTitle}>
            Notifications
          </Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Notifications</Text>
              <Text variant="body2" color="secondary">
                Meditation reminders and achievements
              </Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: colors.neutral.light, true: colors.primary.light }}
              thumbColor={notificationsEnabled ? colors.primary.main : colors.neutral.lighter}
            />
          </View>

          <TouchableOpacity 
            style={[
              styles.settingItem, 
              { opacity: notificationsEnabled ? 1 : 0.5 }
            ]}
            disabled={!notificationsEnabled}
          >
            <View style={styles.settingInfo}>
              <Text>Daily Reminder</Text>
              <Text variant="body2" color="secondary">
                {reminderTime}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>
        </View>

        {/* Playback settings */}
        <View style={[styles.section, { backgroundColor: colors.background.paper }]}>
          <Text variant="h4" style={styles.sectionTitle}>
            Playback & Downloads
          </Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Download Only on WiFi</Text>
            </View>
            <Switch
              value={downloadOverWifi}
              onValueChange={setDownloadOverWifi}
              trackColor={{ false: colors.neutral.light, true: colors.primary.light }}
              thumbColor={downloadOverWifi ? colors.primary.main : colors.neutral.lighter}
            />
          </View>

          <TouchableOpacity style={styles.settingItem} onPress={() => setDownloadManagerVisible(true)}>
            <View style={styles.settingInfo}>
              <Text>Download Quality</Text>
              <Text variant="body2" color="secondary">
                {downloadQuality}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Auto-Play Next Meditation</Text>
            </View>
            <Switch
              value={autoPlayNext}
              onValueChange={setAutoPlayNext}
              trackColor={{ false: colors.neutral.light, true: colors.primary.light }}
              thumbColor={autoPlayNext ? colors.primary.main : colors.neutral.lighter}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Background Sounds</Text>
            </View>
            <Switch
              value={backgroundSounds}
              onValueChange={setBackgroundSounds}
              trackColor={{ false: colors.neutral.light, true: colors.primary.light }}
              thumbColor={backgroundSounds ? colors.primary.main : colors.neutral.lighter}
            />
          </View>
        </View>

        {/* Account settings */}
        <View style={[styles.section, { backgroundColor: colors.background.paper }]}>
          <Text variant="h4" style={styles.sectionTitle}>
            Account
          </Text>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Change Password</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Manage Downloaded Content</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text color="error">Delete Account</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.error.main} />
          </TouchableOpacity>
        </View>

        {/* App info */}
        <View style={[styles.section, { backgroundColor: colors.background.paper }]}>
          <Text variant="h4" style={styles.sectionTitle}>
            About
          </Text>

          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => navigation.navigate('About')}
          >
            <View style={styles.settingInfo}>
              <Text>About MindfulMastery</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => navigation.navigate('PrivacyPolicy')}
          >
            <View style={styles.settingInfo}>
              <Text>Privacy Policy</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.settingItem}
            onPress={() => navigation.navigate('TermsOfService')}
          >
            <View style={styles.settingInfo}>
              <Text>Terms of Service</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.text.secondary} />
          </TouchableOpacity>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text>Version</Text>
              <Text variant="body2" color="secondary">
                1.0.0
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
      
      {/* Download Manager Modal */}
      <DownloadManager
        visible={downloadManagerVisible}
        onClose={() => setDownloadManagerVisible(false)}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  placeholder: {
    width: 24,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  section: {
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
  },
  sectionTitle: {
    padding: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#EAEDF2',
  },
  settingInfo: {
    flex: 1,
  },
  themeButtons: {
    flexDirection: 'row',
  },
  themeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    borderWidth: 1,
  },
});

export default SettingsScreen;
