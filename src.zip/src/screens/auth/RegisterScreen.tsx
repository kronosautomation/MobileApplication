import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../types';
import { TextInput, Button } from '../../components/ui';
import { useAuth } from '../../context';

type RegisterScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'Register'>;

const RegisterScreen: React.FC = () => {
  const navigation = useNavigation<RegisterScreenNavigationProp>();
  const { register, error: authError, clearError } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [loading, setLoading] = useState(false);
  const [validationError, setValidationError] = useState('');

  // Reset errors when changing inputs
  const handleInputChange = (setter: React.Dispatch<React.SetStateAction<string>>) => (text: string) => {
    if (validationError) setValidationError('');
    if (authError) clearError();
    setter(text);
  };

  const validateForm = (): boolean => {
    // Email validation
    if (!email.trim()) {
      setValidationError('Email is required');
      return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setValidationError('Please enter a valid email address');
      return false;
    }

    // Username validation
    if (!username.trim()) {
      setValidationError('Username is required');
      return false;
    }
    
    // Password validation
    if (!password) {
      setValidationError('Password is required');
      return false;
    }
    
    if (password.length < 8) {
      setValidationError('Password must be at least 8 characters long');
      return false;
    }
    
    // Confirm password validation
    if (password !== confirmPassword) {
      setValidationError('Passwords do not match');
      return false;
    }
    
    return true;
  };

  const handleRegister = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      // Call the backend registration endpoint
      await register({
        email,
        username,
        password,
        firstName: firstName.trim() || undefined,
        lastName: lastName.trim() || undefined
      });
      // Registration successful - AuthNavigator will handle navigation
    } catch (error) {
      // Error is handled by the auth context and displayed below
      console.error('Registration failed:', error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const getFieldError = (fieldName: string): string => {
    if (!validationError) return '';
    return validationError.toLowerCase().includes(fieldName.toLowerCase()) ? validationError : '';
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <Text style={styles.title}>Create Account</Text>
      <Text style={styles.subtitle}>Sign up to get started</Text>
      
      <View style={styles.form}>
        <TextInput
          label="Username"
          value={username}
          onChangeText={handleInputChange(setUsername)}
          placeholder="Choose a username"
          autoCapitalize="none"
          leftIcon="person-outline"
          error={getFieldError('username')}
        />
        
        <TextInput
          label="Email"
          value={email}
          onChangeText={handleInputChange(setEmail)}
          placeholder="Enter your email"
          keyboardType="email-address"
          autoCapitalize="none"
          leftIcon="mail-outline"
          error={getFieldError('email')}
        />
        
        <View style={styles.nameRow}>
          <TextInput
            label="First Name (Optional)"
            value={firstName}
            onChangeText={handleInputChange(setFirstName)}
            placeholder="First name"
            style={styles.nameInput}
          />
          
          <TextInput
            label="Last Name (Optional)"
            value={lastName}
            onChangeText={handleInputChange(setLastName)}
            placeholder="Last name"
            style={styles.nameInput}
          />
        </View>
        
        <TextInput
          label="Password"
          value={password}
          onChangeText={handleInputChange(setPassword)}
          placeholder="Create a password"
          secure
          leftIcon="lock-closed-outline"
          error={getFieldError('password') && !getFieldError('match') ? getFieldError('password') : ''}
        />
        
        <TextInput
          label="Confirm Password"
          value={confirmPassword}
          onChangeText={handleInputChange(setConfirmPassword)}
          placeholder="Confirm your password"
          secure
          leftIcon="lock-closed-outline"
          error={getFieldError('match')}
        />
        
        <Button
          title="Create Account"
          onPress={handleRegister}
          loading={loading}
          style={styles.button}
        />
        
        {authError && (
          <Text style={styles.errorText}>{authError}</Text>
        )}
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>Already have an account? </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.footerLink}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F8FA',
  },
  contentContainer: {
    padding: 24,
    paddingBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 40,
    marginBottom: 8,
    color: '#161C2C',
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 32,
    color: '#545D70',
  },
  form: {
    marginBottom: 24,
  },
  nameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  nameInput: {
    flex: 1,
    marginHorizontal: 4,
  },
  button: {
    marginTop: 16,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 14,
    marginTop: 16,
    textAlign: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
  },
  footerText: {
    color: '#545D70',
    fontSize: 14,
  },
  footerLink: {
    color: '#4A62FF',
    fontSize: 14,
    fontWeight: '600',
  },
});

export default RegisterScreen;