import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../types';
import { TextInput, Button } from '../../components/ui';
import { authService } from '../../api';

type ForgotPasswordScreenNavigationProp = NativeStackNavigationProp<AuthStackParamList, 'ForgotPassword'>;

const ForgotPasswordScreen: React.FC = () => {
  const navigation = useNavigation<ForgotPasswordScreenNavigationProp>();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [apiError, setApiError] = useState('');

  const handleEmailChange = (text: string) => {
    if (validationError) setValidationError('');
    if (apiError) setApiError('');
    setEmail(text);
  };

  const validateEmail = () => {
    if (!email.trim()) {
      setValidationError('Email is required');
      return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setValidationError('Please enter a valid email address');
      return false;
    }
    
    return true;
  };

  const handleResetPassword = async () => {
    // Validate email first
    if (!validateEmail()) {
      return;
    }

    setLoading(true);
    try {
      // Note: This endpoint needs to be implemented in the backend
      // For now, we'll just simulate success for demonstration purposes
      // await authService.requestPasswordReset(email);
      
      // TODO: Remove this simulation once backend supports password reset
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Show success state
      setSent(true);
    } catch (error) {
      // Handle error
      if (error instanceof Error) {
        setApiError(error.message);
      } else {
        setApiError('Failed to send password reset email. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>← Back</Text>
      </TouchableOpacity>
      
      <Text style={styles.title}>Reset Password</Text>
      
      {sent ? (
        <View style={styles.successContainer}>
          <Text style={styles.successTitle}>Check Your Email</Text>
          <Text style={styles.successMessage}>
            We've sent password reset instructions to {email}
          </Text>
          <Button
            title="Back to Login"
            onPress={() => navigation.navigate('Login')}
            style={styles.button}
          />
        </View>
      ) : (
        <>
          <Text style={styles.subtitle}>
            Enter your email address and we'll send you instructions to reset your password
          </Text>
          
          <View style={styles.form}>
            <TextInput
              label="Email"
              value={email}
              onChangeText={handleEmailChange}
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon="mail-outline"
              error={validationError}
            />
            
            {apiError && (
              <Text style={styles.errorText}>{apiError}</Text>
            )}
            
            <Button
              title="Send Reset Link"
              onPress={handleResetPassword}
              loading={loading}
              style={styles.button}
            />
          </View>
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#F7F8FA',
  },
  backButton: {
    marginTop: 16,
    marginBottom: 24,
  },
  backButtonText: {
    fontSize: 16,
    color: '#4A62FF',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#161C2C',
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 32,
    color: '#545D70',
    lineHeight: 24,
  },
  form: {
    marginBottom: 24,
  },
  button: {
    marginTop: 16,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 14,
    marginTop: 16,
    textAlign: 'center',
  },
  successContainer: {
    marginTop: 40,
    alignItems: 'center',
  },
  successTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#161C2C',
  },
  successMessage: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 40,
    color: '#545D70',
    lineHeight: 24,
  },
});

export default ForgotPasswordScreen;