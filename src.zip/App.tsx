import React, { useEffect, useState } from 'react';
import { StatusBar, LogBox } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import * as SplashScreen from 'expo-splash-screen';
import * as Font from 'expo-font';
import { Ionicons } from '@expo/vector-icons';
import { ThemeProvider } from './src/context/ThemeContext';
import { AuthProvider } from './src/context/AuthContext';
import { SubscriptionProvider } from './src/context/SubscriptionContext';
import AppNavigator from './src/navigation/AppNavigator';
import { ErrorBoundary, AppErrorProvider, OfflineNotice } from './src/components/common';
import { initializeOfflineServices } from './src/services/storage';

// Ignore specific deprecation warnings that we can't fix
LogBox.ignoreLogs([
  'ViewPropTypes will be removed from React Native',
  'AsyncStorage has been extracted from react-native',
]);

// Keep the splash screen visible until the app is ready
SplashScreen.preventAutoHideAsync();

// App content component with loading logic
function AppContent() {
  const [appIsReady, setAppIsReady] = useState(false);
  
  useEffect(() => {
    // Load resources asynchronously
    async function prepare() {
      try {
        // Load fonts
        await Font.loadAsync({
          'Inter-Regular': require('./assets/fonts/Inter-Regular.ttf'),
          'Inter-Medium': require('./assets/fonts/Inter-Medium.ttf'),
          'Inter-SemiBold': require('./assets/fonts/Inter-SemiBold.ttf'),
          'Inter-Bold': require('./assets/fonts/Inter-Bold.ttf'),
          ...Ionicons.font,
        });
        
        // Initialize offline services
        await initializeOfflineServices();
        
      } catch (e) {
        console.warn('Error loading resources:', e);
      } finally {
        // App is ready to be displayed
        setAppIsReady(true);
      }
    }

    prepare();
  }, []);

  useEffect(() => {
    // Hide the splash screen once the app is ready
    if (appIsReady) {
      SplashScreen.hideAsync().catch(error => {
        console.warn('Error hiding splash screen:', error);
      });
    }
  }, [appIsReady]);

  if (!appIsReady) {
    return null;
  }

  return (
    <NavigationContainer>
      <ErrorBoundary>
        <AppErrorProvider>
          <OfflineNotice />
          <AppNavigator />
        </AppErrorProvider>
      </ErrorBoundary>
    </NavigationContainer>
  );
}

// Main App component
export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider>
          <AuthProvider>
            <SubscriptionProvider>
              <StatusBar 
                barStyle="dark-content"
                backgroundColor="transparent"
                translucent
              />
              <AppContent />
            </SubscriptionProvider>
          </AuthProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
